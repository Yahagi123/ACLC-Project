<?php

    define('MAILHOST', "smtp.gmail.com");

    define('USERNAME', "m70455067@gmail.com");

    define('PASSWORD', "jmhq gquk tdce wdab");

    define('SEND_FROM', "m70455067@gmail.com");

    define('SEND_FROM_NAME', "Fingerprint Register");

    define('REPLY_TO', "m70455067@gmail.com");

    define('REPLY_TO_NAME', "MrDuck");

?>